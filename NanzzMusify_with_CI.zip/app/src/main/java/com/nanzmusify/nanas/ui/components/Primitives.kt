/*
 * Copyright (C) 2026 Nanas
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.nanzmusify.nanas.ui.theme.NanzMusifyHairline
import com.nanzmusify.nanas.ui.theme.NanzMusifyRadius
import com.nanzmusify.nanas.ui.theme.NanzMusifySurface
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary

@Composable
fun RevealOnScroll(modifier: Modifier = Modifier, delayMs: Int = 0, fromY: Float = 48f, content: @Composable () -> Unit) {
    Box(modifier = modifier) { content() }
}

@Composable
fun BrutalFrame(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(NanzMusifyRadius.md)
    Box(modifier.fillMaxWidth().clip(shape).background(NanzMusifySurface).border(1.dp, NanzMusifyHairline, shape)) { content() }
}

@Composable
fun SectionRule(label: String, modifier: Modifier = Modifier, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = NanzMusifyTextPrimary)
        if (actionLabel != null && onAction != null) {
            Text(actionLabel, style = MaterialTheme.typography.labelLarge, color = NanzMusifyTextSecondary,
                modifier = Modifier.clip(RoundedCornerShape(NanzMusifyRadius.xs)).clickable(onClick = onAction).padding(horizontal = 8.dp, vertical = 4.dp))
        }
    }
}
