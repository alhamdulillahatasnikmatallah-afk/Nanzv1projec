/*
 * Copyright (C) 2026 Nanas
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nanzmusify.nanas.R
import com.nanzmusify.nanas.data.model.NanzMusifyTrack
import com.nanzmusify.nanas.data.model.formatDuration
import com.nanzmusify.nanas.ui.theme.NanzMusifyCrimson
import com.nanzmusify.nanas.ui.theme.NanzMusifyRadius
import com.nanzmusify.nanas.ui.theme.NanzMusifyRose
import com.nanzmusify.nanas.ui.theme.NanzMusifySurface
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextMuted
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary

@Composable
fun TrackRow(
    track: NanzMusifyTrack,
    isActive: Boolean,
    isPlaying: Boolean,
    isLiked: Boolean,
    isDownloaded: Boolean,
    index: Int?,
    onPlay: () -> Unit,
    onLike: () -> Unit,
    onMore: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val bgColor = if (isActive) NanzMusifySurface.copy(alpha = 0.55f) else androidx.compose.ui.graphics.Color.Transparent
    Row(
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(NanzMusifyRadius.sm))
            .background(bgColor).clickable(onClick = onPlay)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (index != null) {
            Text("${index + 1}", style = MaterialTheme.typography.labelMedium,
                color = if (isActive) NanzMusifyCrimson else NanzMusifyTextMuted, modifier = Modifier.width(28.dp))
        }
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(NanzMusifyRadius.xs))) {
            Artwork(url = track.thumbnailUrl, title = track.title, size = 52.dp)
            if (isActive) {
                Box(Modifier.matchParentSize().background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center) {
                    NanzMusifyMiniPlay(isPlaying = isPlaying, onClick = onPlay, size = 26.dp)
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, style = MaterialTheme.typography.bodyLarge,
                color = if (isActive) NanzMusifyCrimson else NanzMusifyTextPrimary,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(buildString {
                append(track.artist.ifBlank { track.album }.ifBlank { stringResource(R.string.common_youtube) })
                if (isDownloaded) append(" · Offline")
            }, style = MaterialTheme.typography.bodySmall, color = NanzMusifyTextSecondary,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(formatDuration(track.durationSec), style = MaterialTheme.typography.labelSmall,
            color = NanzMusifyTextMuted, modifier = Modifier.padding(end = 4.dp))
        IconButton(onClick = onLike, modifier = Modifier.size(36.dp)) {
            Icon(if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = stringResource(R.string.np_like_add),
                tint = if (isLiked) NanzMusifyRose else NanzMusifyTextMuted, modifier = Modifier.size(20.dp))
        }
        IconButton(onClick = onMore, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Filled.MoreVert, contentDescription = "Lainnya",
                tint = NanzMusifyTextMuted, modifier = Modifier.size(20.dp))
        }
    }
}
